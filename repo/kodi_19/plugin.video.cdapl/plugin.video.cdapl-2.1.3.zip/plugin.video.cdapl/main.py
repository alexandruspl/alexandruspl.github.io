# -*- coding: utf-8 -*-
"""plugin.video.cdapl"""

import json
import os
import sqlite3
import sys
import traceback

import six
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from six.moves import urllib_parse as urlparse

from lib import cda, menu
from lib.cda import plugin_handle
from lib import search_history, logger
from lib.cda import search_cache
from lib.downloader.db import URLDb

if six.PY2:
    xbmcvfs.translatePath = xbmc.translatePath

addon = xbmcaddon.Addon()
xbmc_profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))

xbmc_favorites_path = os.path.join(
    xbmc_profile_path, 'favorites.json')


def search(ex_link):
    cache_days = addon.getSetting('cache_search_days')
    items, next_page = search_cache.load(ex_link, cache_days)
    premium_cda_ = True if addon.getSetting('search_premium') == 'true' else False
    bcleantitle_cda = True if addon.getSetting('bcleanTitle') == 'true' else False
    if not items:
        items, next_page = cda.get_items(ex_link, premium_cda_, bcleantitle_cda)
        ct = 0
        while len(items) < 5 and ct < 4 and next_page:
            xbmc.Monitor().waitForAbort(6)
            tmp_items, next_page = cda.get_items(next_page, premium_cda_, bcleantitle_cda)
            items = items + tmp_items
            ct = ct + 1
    if items:
        search_cache.save(ex_link, items, next_page)
        for item in items:
            menu.add_menu_item(label=item.get('title'), ex_link=item.get('path'),
                               mode='play', iconImage=item.get('img'), infoLabels=item,
                               IsPlayable=True, fanart=item.get('img'), totalItems=len(items))
        if next_page:
            menu.add_folder_item(
                '[COLOR gold]Następna strona >> [/COLOR] ',
                ex_link=next_page, mode='cdaSearch', iconImage='next.png')
    menu.sort_methods()
    xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)


def clean_search_cache():
    clean_time = addon.getSetting('cache_search_clean_time') if addon.getSetting('cache_search_clean_time') else 0
    last_clean_time = search_cache.clean(addon.getSetting('cache_search_days'), clean_time)
    if float(clean_time) < float(last_clean_time):
        addon.setSetting('cache_search_clean_time', str(last_clean_time))


def main():
    try:
        args = urlparse.parse_qs(sys.argv[2][1:])
    except IndexError:
        args = {}
    ex_link = args.get('ex_link', [''])[0]
    mode = args.get('mode')[0] if args.get('mode', '') else ''
    xbmcplugin.setContent(plugin_handle, 'movies')
    foldername = args.get('foldername', [''])[0]
    json_file = args.get('json_file', [''])[0]
    logger.log('CDA: %s' % str(sys.argv))

    clean_search_cache()

    if mode == 'premiumKat':
        def premiumKat():
            sortuj_po = addon.getSetting('sortuj_po')
            jakosc_premium = addon.getSetting('jakosc_premium')
            menu.add_folder_item(' [COLOR white]== Sortuj po: [I]%s[/I] [/COLOR]' % sortuj_po, ex_link='',
                                 json_file='', mode='premiumSort', iconImage='')
            menu.add_folder_item(' [COLOR white]== Jakość: [I]%s[/I] [/COLOR]' % jakosc_premium,
                                 ex_link='', json_file='', mode='premiumQuality', iconImage='')
            try:
                for video in cda.premium_videos():
                    menu.add_folder_item(video.get('title'), ex_link=video.get('path'), json_file='', mode='premiumFilm',
                                         iconImage=video.get(
                                             'img', ''), infoLabels=video, fanart=video.get('fanart', ''))
            except:
                pass

            xbmcplugin.endOfDirectory(plugin_handle, succeeded=True, cacheToDisc=False)

        premiumKat()
    elif mode.startswith('__page'):
        mode_split = mode.split(':')[-1]
        url = cda.gen_url(
            {'mode': mode_split, 'foldername': foldername, 'ex_link': ex_link,
             'json_file': json_file})
        xbmc.executebuiltin('Container.Refresh(%s)' % url)
        xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)
    elif mode == 'premiumSort':
        selected_option = xbmcgui.Dialog().select(
            'Sortuj po:', list(cda.sort_methods.keys()))
        if selected_option > -1:
            sorting_method = list(cda.sort_methods.keys())[selected_option]
            addon.setSetting('sortuj_po', sorting_method)
            xbmc.executebuiltin('Container.Refresh')
    elif mode == 'premiumQuality':
        selected_option = xbmcgui.Dialog().select(
            'Jakość:', list(cda.premium_quality_list.keys()))
        if selected_option > -1:
            sorting_method = list(cda.premium_quality_list.keys())[selected_option]
            addon.setSetting('jakosc_premium', sorting_method)
            xbmc.executebuiltin('Container.Refresh')
    elif mode == 'premiumFilm':
        def premiumFilm():
            sortuj_po = addon.getSetting('sortuj_po')
            jakosc_premium = addon.getSetting('jakosc_premium')
            if '?' not in ex_link:
                url = ex_link + '?sort=%s&q=%s&d=2' % (cda.sort_methods.get(
                    sortuj_po, ''), cda.premium_quality_list.get(jakosc_premium, ''))
            else:
                url = ex_link
            items, params = cda.premium_film(url, json_file)
            for item in items:
                name = cda.html_entity_decode(item.get('title', ''))
                item_url = item.get('path', '')
                if 'folder' in item_url:
                    menu.add_folder_item(
                        name, ex_link=item_url, json_file='ignore',
                        mode='walk', infoLabels=item, iconImage=item.get('img'))
                else:
                    menu.add_menu_item(label=name, ex_link=item_url, mode='play', context=[], iconImage=item.get(
                        'img'), infoLabels=item, IsPlayable=True, fanart=item.get('img'), totalItems=len(items))
            if params:
                menu.add_folder_item('[COLOR gold]Następna strona >> [/COLOR] ',
                                     ex_link=url, json_file=params, mode='premiumFilm', iconImage='next.png')
            xbmcplugin.endOfDirectory(
                plugin_handle, succeeded=True, cacheToDisc=False)

        premiumFilm()
    elif mode == 'favoritesADD':
        def favoritesAdd():
            json_cda = cda.load_json(xbmc_favorites_path)
            json_data = json.loads(ex_link)
            logger.log(ex_link)
            logger.log(str(json_data))
            json_data['title'] = json_data.get('title', '').replace(
                json_data.get('label', ''), '').replace(json_data.get('msg', ''), '')
            selected = [
                x for x in json_cda if json_data['title'] == x.get('title', '')]
            if selected:
                xbmc.executebuiltin(
                    'Notification([COLOR pink]Już jest w Wybranych[/COLOR], ' + json_data.get('title', '') + ', 200)')
            else:
                json_cda.append(json_data)
                with open(xbmc_favorites_path, 'w') as favorites_f:
                    json.dump(json_cda,
                              favorites_f, indent=2, sort_keys=True)
                    xbmc.executebuiltin(
                        'Notification(Dodano Do Wybranych, ' + json_data.get('title', '') + ', 200)')

        favoritesAdd()
    elif mode == 'favoritesREM':
        def favoritesRem():
            if ex_link == 'all':
                xbmcgui_dialog = xbmcgui.Dialog().yesno(
                    '??', 'Usuń wszystkie filmy z Wybranych?')
            else:
                json_cda = cda.load_json(xbmc_favorites_path)
                json_obj = json.loads(ex_link)
                to_remove = [i for i, val in enumerate(json_cda) if val.get('title') in json_obj.get('title')]

                if len(to_remove) > 1:
                    xbmcgui_dialog = xbmcgui.Dialog().yesno('??', json_obj.get(
                        'title'), 'Usuń %d pozycji z Wybranych?' % len(to_remove))
                else:
                    xbmcgui_dialog = True
                if xbmcgui_dialog:
                    for i in reversed(to_remove):
                        json_cda.pop(i)
                    with open(xbmc_favorites_path, 'w') as favorites_f:
                        json.dump(json_cda, favorites_f, indent=2, sort_keys=True)
            xbmc.executebuiltin('Container.Refresh')

        favoritesRem()
    elif mode == 'cdaSearch':
        search(ex_link)
    elif mode == 'Szukaj':
        def szukaj():
            menu.add_folder_item(
                '[COLOR lightblue]Nowe Szukanie[/COLOR]', '', mode='SzukajNowe')
            history = search_history.get()
            if history:
                for search_item in history:
                    contextmenu = [('Usuń', 'Container.Update(%s)' %
                                    cda.gen_url({'mode': 'SzukajUsun', 'ex_link': search_item})),
                                   ('Usuń całą historię', 'Container.Update(%s)' % cda.gen_url({'mode': 'SzukajUsunAll'}))]
                    menu.add_folder_item(label=search_item, ex_link='https://www.cda.pl/video/show/' +
                                                                    search_item.replace(' ', '_') +
                                                                    '?section=vid&quality=all&s=best',
                                         mode='cdaSearch', fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(
                plugin_handle, succeeded=True, cacheToDisc=False)

        szukaj()
    elif mode == 'SzukajNowe':
        dialog_input = xbmcgui.Dialog().input(
            'Szukaj, podaj tytuł', type=xbmcgui.INPUT_ALPHANUM)
        if dialog_input:
            search_history.add(dialog_input)
            ex_link = 'https://www.cda.pl/video/show/' + \
                      dialog_input.replace(' ', '_')
            search(ex_link)
    elif mode == 'SzukajUsun':
        search_history.remove(ex_link)
        xbmc.executebuiltin('Container.Refresh(%s)' %
                            cda.gen_url({'mode': 'Szukaj'}))
        xbmcplugin.endOfDirectory(
            plugin_handle, succeeded=True, cacheToDisc=False)
    elif mode == 'SzukajUsunAll':
        search_history.clear()
        xbmc.executebuiltin('Container.Refresh(%s)' %
                            cda.gen_url({'mode': 'Szukaj'}))
        xbmcplugin.endOfDirectory(
            plugin_handle, succeeded=True, cacheToDisc=False)
    elif mode == 'MojeCDA':
        def mojeCDA():
            u = addon.getSetting('user')
            if u:
                menu.add_folder_item('Folder główny', ex_link='https://www.cda.pl/' +
                                                              u + '/folder-glowny?type=pliki', json_file='',
                                     mode='walk',
                                     iconImage='cdaMoje.png')
                menu.add_folder_item('Ulubione', ex_link='https://www.cda.pl/' + u +
                                                         '/ulubione/folder-glowny?type=pliki', json_file='',
                                     mode='walk',
                                     iconImage='cdaUlubione.png')
                menu.add_folder_item('Obserwowani użcytkownicy', ex_link='https://www.cda.pl/' +
                                                                         u + '/obserwowani', json_file='', mode='walk',
                                     iconImage='cdaObserwowani.png')
            xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)

        mojeCDA()
    elif mode == 'play':
        # uruchamia odtwarzacz dla filmów z Szukaj, Premium, Wybrane
        logger.info('play: %s' % ex_link)
        cda.play(ex_link, foldername)
    elif mode == 'download':
        def download(ex_link):
            DB_PATH = addon.getSetting('db_path')
            try:
                cn = sqlite3.connect(DB_PATH)
            except sqlite3.Error:
                logger.warning(traceback.format_exc())
                return
            db = URLDb(cn)
            stream_type, video_urls = cda.get_video_urls(ex_link)
            if stream_type == 'dash':
                xbmcgui.Dialog().ok('DASH VIDEO', "Can't download dash video")
                return

            quality = addon.getSetting('quality')
            video_urls = cda.video_quality(video_urls, int(quality))
            video_urls = video_urls.split('|')[0]
            title = args.get('title', [''])[0]
            result = urlparse.urlparse(video_urls)
            ext = result.path.rsplit('.')[-1] if len(result.path.rsplit('.')) > 1 else ''
            filename = '{}.{}'.format(title.strip(), ext)
            db.add(video_urls, filename)
        download(ex_link)
    elif mode == 'Opcje':
        addon.openSettings()
        xbmc.executebuiltin('Container.Refresh()')
    elif mode == 'UserContent':
        info = cda.grabInforFromLink(urlparse.unquote(ex_link))
        user = info.get('user', '')
        if user:
            menu.folder_cda(user, '', '')
            xbmcplugin.endOfDirectory(
                plugin_handle, succeeded=True, cacheToDisc=False)
        else:
            xbmcgui.Dialog().notification(
                'Folder nie jest dostępny', '', xbmcgui.NOTIFICATION_INFO, 5000)

    elif mode == 'walk':
        logger.log('CDA: %s | %s | %s' %
                   (ex_link, json_file, foldername))
        menu.folder_cda(ex_link, json_file, foldername)
        xbmcplugin.endOfDirectory(
            plugin_handle, succeeded=True, cacheToDisc=False)
    elif mode == 'play_url':
        video_url = ''
        video_url = xbmcgui.Dialog().input('Podaj adres filmu', video_url)
        if video_url:
            logger.info('play_url: %s' % video_url)
            encoded_url, list_item, _ =menu.cda_play(video_url)
            xbmc.Player().play(encoded_url,list_item)
        else:
            xbmcgui.Dialog().notification('Failed to play url', '', xbmcgui.NOTIFICATION_INFO, 5000)

    else:
        def default():
            menu.cda_user()    
            menu.folder_cda()
            menu.user_folders()
            menu.add_folder_item('[COLOR white][B]Filmy Premium[/B][/COLOR]', ex_link='', mode='premiumKat',
                                 iconImage='MediaPremium.png')
            menu.add_folder_item(
                '[COLOR khaki]Wybrane[/COLOR]', ex_link='', json_file=xbmc_favorites_path, mode='walk',
                iconImage='cdaUlubione.png',
                infoLabels={'plot': 'Lista wybranych pozycji. Szybki dostep, lokalna baza danych.'})
            menu.add_folder_item('Szukaj', ex_link='', mode='Szukaj',
                                 iconImage='Szukaj_cda.png')
            menu.add_menu_item(label = 'Play video url', ex_link='', mode='play_url')
            menu.add_menu_item(label='-=Opcje=-', ex_link='', mode='Opcje',
                               iconImage=xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/' + 'Opcje.png',
                               infoLabels=False, context=[])
            xbmcplugin.endOfDirectory(plugin_handle, succeeded=True)

        default()


if __name__ == '__main__':
    main()
