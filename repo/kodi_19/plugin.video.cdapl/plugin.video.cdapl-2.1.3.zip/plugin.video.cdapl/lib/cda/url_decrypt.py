# -*- coding: utf-8 -*-

from six.moves.urllib_parse import unquote

from .. import logger


def decrypt(a):
    # first replace very cringy joke, then apply decodeURIComponent
    a = unquote(a)
    logger.log('cda: %s' % str(a))
    if a.find('_') <= 0:
        return ''
    a = a[:a.rfind('_')]
    # store decrypted characters
    b = []
    for e in a:
        f = ord(e)
        b.append(chr(33 + (f + 14) % 94) if 33 <= f <= 126 else chr(f))
    # decrypted URL
    a = "".join(b)
    # more "obfuscation" to deal with
    a = a.replace(".cda.mp4", "")
    a = a.replace(".2cda.pl", ".cda.pl")
    a = a.replace(".3cda.pl", ".cda.pl")
    # return extracted file as URL to video file
    return "https://" + a + ".mp4"

