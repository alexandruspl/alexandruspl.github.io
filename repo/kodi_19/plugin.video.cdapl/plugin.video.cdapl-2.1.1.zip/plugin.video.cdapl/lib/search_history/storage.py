import os
import traceback
import json

import six

from lib import logger


class JsonStorage(object):
    FILEPATH = None

    def __init__(self, cache_dir):
        self.CACHE_DIR = cache_dir
        self.FILEPATH = os.path.join(self.CACHE_DIR, "search.txt")
        if not os.path.exists(self.CACHE_DIR):
            try:
                os.mkdir(self.CACHE_DIR)
            except Exception:
                logger.log('CDA_SEARCH_HISTORY: %s' % traceback.format_exc(), logger.LOGWARNING)
                return

    def get(self):
        try:
            with open(self.FILEPATH, 'r') as f:
                content = [six.ensure_str(val) for val in json.load(f)]
        except ValueError:
            logger.log("CDA: {}".format(traceback.format_exc()), logger.LOGWARNING)
            return self._import_txt()
        except Exception:
            logger.log("CDA: {}".format(traceback.format_exc()), logger.LOGWARNING)
            return
        return content

    def set(self, value):
        """save data
        """
        try:
            json.dumps(value)
            with open(self.FILEPATH, 'w') as f:
                json.dump(value, f, indent=4)
        except Exception:
            logger.log("CDA: {}".format(traceback.format_exc()), logger.LOGWARNING)


    def _import_txt(self):
        try:
            with open(self.FILEPATH, 'r') as f:
                content = f.read()
                if not content:
                    return
                self.set(content.split(';'))
                return content.split(';')
        except:
            logger.log("CDA: {}".format(traceback.format_exc()), logger.LOGWARNING)