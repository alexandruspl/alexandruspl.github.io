# -*- coding: utf-8 -*-

import xbmcgui

class xbmc_ui:
    @staticmethod
    def download_dialog():
        return xbmcgui.Dialog().browseSingle(3, "Katalog pobierania", 'files')

    @staticmethod
    def file_exists_dialog(filename):
        return xbmcgui.Dialog().input('Plik już istnieje', filename)

    @staticmethod
    def progress_dialog_bg():
        return xbmcgui.DialogProgressBG()

    @staticmethod
    def notification_dialog(heading, msg):
        xbmcgui.Dialog().notification(heading, msg)