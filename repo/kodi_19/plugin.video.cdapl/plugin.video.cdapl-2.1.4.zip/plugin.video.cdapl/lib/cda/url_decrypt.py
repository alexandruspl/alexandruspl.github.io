# -*- coding: utf-8 -*-
from __future__ import unicode_literals, print_function  # Ensures compatibility with Python 3 behavior
from six.moves.urllib_parse import unquote
from .. import logger

def decrypt(a):
    """
    Decrypt an obfuscated video URL from cda.pl.

    Args:
        a (str): The encrypted URL string.

    Returns:
        str: The decrypted video URL.
    """
    # Decode URL encoding
    a = unquote(a)
    logger.log('cda: %s' % a)  # Old-style string formatting for compatibility

    # Ensure it contains an underscore
    if "_" not in a:
        return ""

    # Remove the last segment after the last underscore
    a = a[:a.rfind("_")]

    # Decrypt characters
    decrypted_chars = []
    for e in a:
        f = ord(e)
        decrypted_chars.append(chr(33 + (f + 14) % 94) if 33 <= f <= 126 else chr(f))
    
    # Construct decrypted string
    a = "".join(decrypted_chars)

    # Remove additional obfuscation
    a = a.replace(".cda.mp4", "")
    a = a.replace(".2cda.pl", ".cda.pl")
    a = a.replace(".3cda.pl", ".cda.pl")

    # Return the final URL
    return "https://%s.mp4" % a  # Old-style string formatting
