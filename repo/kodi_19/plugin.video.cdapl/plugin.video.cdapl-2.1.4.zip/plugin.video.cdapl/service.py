# -*- coding: utf-8 -*-
import os
import sqlite3
import six
import xbmc
import xbmcaddon

from lib import downloader, logger
from lib.downloader.db import URLDb
import traceback

if six.PY2:
    from xbmc import translatePath
else:
    from xbmcvfs import translatePath

def main():
    DB_PATH = translatePath('special://temp/plugin.video.cdapl/cda.db')
    addon = xbmcaddon.Addon()

    if addon.getSetting('db_path') != DB_PATH:
        addon.setSetting('db_path', DB_PATH)
    
    db_dir = os.path.dirname(DB_PATH)
    if not os.path.exists(db_dir):
        try:
            os.makedirs(db_dir)
        except OSError:
            logger.warning('CDA SERVICE: Can\'t create database directory')
            return
    
    try:
        with sqlite3.connect(DB_PATH) as cn:
            url_db = URLDb(cn)
            while not xbmc.Monitor().abortRequested():
                url_data = url_db.next()
                if url_data:
                    try:
                        result = downloader.download(url_data[0], url_data[1])
                        if result:
                            url_db.set_state(url_data[0], downloader.STATE_DOWNLOADED)
                            url_db.set_filename(url_data[0], result[1])
                        else:
                            url_db.set_state(url_data[0], downloader.STATE_ERR)
                    except Exception as e:
                        logger.error("Error downloading %s : %s" % (url_data[0], e))
                        logger.error("traceback: %s" % traceback.format_exc())
                        url_db.set_state(url_data[0], downloader.STATE_ERR)

                xbmc.Monitor().waitForAbort(0.1)
    except sqlite3.Error as e:
        logger.error("Database error: %s" % e)
    except Exception as e:
        logger.error("Unexpected error: %s" % e)

if __name__ == '__main__':
    main()