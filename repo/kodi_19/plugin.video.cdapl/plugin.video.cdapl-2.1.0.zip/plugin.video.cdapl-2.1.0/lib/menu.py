# -*- coding: utf-8 -*-

import json
import traceback

import six
import xbmcgui
import xbmcplugin

from . import logger, cda
from .common import *


def add_menu_item(label, ex_link, mode, iconImage='DefaultFolder.png', infoLabels=False, context=('F_ADD', 'DOWNLOAD'),
                  IsPlayable=False, fanart=None,
                  totalItems=1):
    encoded_url, list_item, _ = _menu_item(label, ex_link, mode, iconImage, infoLabels, context, IsPlayable, fanart)
    status = xbmcplugin.addDirectoryItem(
        handle=plugin_handle, url=encoded_url, listitem=list_item, isFolder=False, totalItems=totalItems)
    xbmcplugin.addSortMethod(
        plugin_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask='%D, %P, %R')
    return status


def add_folder_item(label, ex_link=None, json_file='', mode='walk', iconImage='DefaultFolder.png', fanart='',
                    infoLabels=False, contextmenu=None):
    url = gen_url(
        {'mode': mode, 'foldername': label, 'ex_link': ex_link, 'json_file': json_file})

    if iconImage != 'DefaultFolder.png' and not iconImage.startswith('http'):
        iconImage = get_media_path() + iconImage
    list_item, infoLabels = _create_list_item(label, iconImage, infoLabels, fanart)

    if contextmenu:
        list_item.addContextMenuItems(contextmenu)
    status = xbmcplugin.addDirectoryItem(
        handle=plugin_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.addSortMethod(
        plugin_handle, sortMethod=xbmcplugin.SORT_METHOD_LABEL, label2Mask='%D, %P, %R')
    xbmcplugin.addSortMethod(
        plugin_handle, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask='%D, %P, %R')
    return status


def folder_cda(ex_link='', json_file='', fname=''):
    PATH = os.path.join(addon.getAddonInfo('path'), 'resources')
    addon_id = addon.getAddonInfo('id')
    logger.log('CDA COMMON: ' + '|'.join([ex_link, json_file, fname]))
    items = []
    folders = []
    pagination = (False, False)
    try:
        items, folders = cda.folder_root(ex_link, json_file, PATH)
    except Exception as ex:
        logger.log('cda exception: %s' % traceback.format_exc(), logger.LOGWARNING)
    if 'folder' in ex_link or 'ulubione' in ex_link:
        recursive = False if addon.getSetting(
            'UserFolder.content.pagination') == 'true' else True
        items, folders, pagination = cda.filter_items(
            ex_link=ex_link,
            recursive=recursive,
            filtr_items={})
    elif 'obserwowani' in ex_link:
        items, folders = cda.get_UserFolder_obserwowani(ex_link)
    if pagination[0]:
        add_menu_item('[COLOR gold] << Poprzednia strona [/COLOR]', ex_link=pagination[
            1], mode='__page:walk', iconImage='prev.png', infoLabels=False, context=[], IsPlayable=False, fanart=None,
                      totalItems=1)
    for folder in folders:
        json_file = folder.get('jsonfile', json_file)
        title = folder.get('title') + folder.get('count', '')
        folder['plot'] = folder.get('plot', '') + '\n' + folder.get('update', '')
        if folder.get('lib', False):
            contextmenu = [(
                '[COLOR lightblue]Dodaj zawartość do Biblioteki[/COLOR]',
                'RunPlugin(plugin://%s?mode=AddRootFolder&json_file=%s)' % (
                    addon_id, urlparse.quote_plus(json_file)))]
        else:
            contextmenu = []
        add_folder_item(title, ex_link=folder.get('url'), json_file=json_file, mode='walk', iconImage=folder.get(
            'img', ''), infoLabels=folder, fanart=folder.get('fanart', ''), contextmenu=contextmenu)
    context = ['F_ADD']
    if fname == '[COLOR khaki]Wybrane[/COLOR]':
        context = ['F_REM', 'F_DEL']
    items_list = [_menu_item(name=item.get('title'), url=item.get('url'), mode='play',
                             context=context, iconImage=item.get('img'), infoLabels=item, IsPlayable=True,
                             fanart=item.get('img')) for item in items]
    xbmcplugin.addDirectoryItems(
        handle=plugin_handle, items=items_list, totalItems=len(items))
    if pagination[1]:
        add_menu_item('[COLOR gold]Następna strona >> [/COLOR] ', ex_link=pagination[
            1], mode='__page:walk', iconImage='next.png', infoLabels=False, context=[], IsPlayable=False, fanart=None,
                      totalItems=1)
    xbmcplugin.addSortMethod(
        plugin_handle, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask='%D, %P, %R')
    sort_methods()


def user_folders():
    for userF in ['K1', 'K2', 'K3', 'K4', 'K5', 'K6']:
        user_folder = _user_folder_cda_(userF)
        if user_folder:
            add_folder_item(user_folder.get('title'), ex_link=user_folder.get(
                'url'), mode='cdaSearch', json_file=user_folder.get('metadata'), iconImage='Szukaj_cda.png')


def cda_user():
    u = addon.getSetting('user')
    p = addon.getSetting('pass')
    if u and p:
        if cda.login(u, p, xbmc_profile_path + 'cookie.cda'):
            add_folder_item('[B]Moje cda.pl[/B]', ex_link='', json_file='',
                            mode='MojeCDA', iconImage='cdaMoje.png', infoLabels=False)


def sort_methods():
    """Add sort methods"""
    methods = [xbmcplugin.SORT_METHOD_TITLE, xbmcplugin.SORT_METHOD_VIDEO_RATING,
               xbmcplugin.SORT_METHOD_VIDEO_YEAR, xbmcplugin.SORT_METHOD_GENRE,
               xbmcplugin.SORT_METHOD_STUDIO, xbmcplugin.SORT_METHOD_VIDEO_RUNTIME,
               xbmcplugin.SORT_METHOD_UNSORTED]
    for method in methods:
        xbmcplugin.addSortMethod(plugin_handle, method)


def _create_list_item(label, icon_image, info_labels, fanart):
    info_labels = {'title': label} if not info_labels else info_labels
    for to_del in ('img', 'new', 'url', 'jsonfile', 'idx', 'update'):
        if to_del in info_labels:
            info_labels.pop(to_del)

    list_item = xbmcgui.ListItem(label)
    list_item.setArt(
        {'poster': icon_image, 'thumb': icon_image, 'icon': icon_image, 'fanart': fanart, 'banner': icon_image})
    list_item.setInfo(type='video', infoLabels=info_labels)
    if fanart:
        list_item.setProperty('fanart_image', fanart)
    return list_item, info_labels


def _menu_item(name, url, mode, iconImage='DefaultFolder.png', infoLabels=False,
               context=['F_ADD'], IsPlayable=False, fanart=None, json_file=''):
    name = six.ensure_str(name)
    folder_url = gen_url(
        {'mode': mode, 'foldername': name, 'ex_link': url, 'json_file': json_file})
    list_item, infoLabels = _create_list_item(name, iconImage, infoLabels, fanart)
    if IsPlayable:
        list_item.setProperty('IsPlayable', 'True')
    list_item.setProperty('mimetype', 'video/x-msvideo')
    context_menu = _submenu(infoLabels, context, url)
    list_item.addContextMenuItems(context_menu)
    return folder_url, list_item, False


def _submenu(infoLabels, context, url):
    addon_id = addon.getAddonInfo('id')
    context_menu = [('[COLOR lightblue]Folder Użcytkownika[/COLOR]', 'Container.Update(%s)' %
                     gen_url({'mode': 'UserContent', 'ex_link': urlparse.quote(url)}))]
    content = urlparse.quote_plus(json.dumps(infoLabels))
    title = urlparse.quote_plus(six.ensure_str(infoLabels['title'])) if 'title' in infoLabels.keys() else ''
    if 'F_ADD' in context:
        context_menu.append(
            ('[COLOR lightblue]Dodaj do Biblioteki[/COLOR]',
             'Container.Update(plugin://%s?mode=AddMovie&ex_link=%s)' % (addon_id, content)))
        context_menu.append(('[COLOR lightblue]Wybór jakości [/COLOR]', 'Container.Update(%s)' %
                             gen_url({'mode': 'play', 'ex_link': urlparse.quote(url)})))
        context_menu.append(
            ('[COLOR lightblue]Dodaj do Wybranych[/COLOR]',
             'RunPlugin(plugin://%s?mode=favoritesADD&ex_link=%s)' % (addon_id, content)))
    if 'F_REM' in context:
        context_menu.append(
            ('[COLOR red]Usuń z Wybranych[/COLOR]',
             'RunPlugin(plugin://%s?mode=favoritesREM&ex_link=%s)' % (addon_id, content)))
    if 'F_DEL' in context:
        context_menu.append(
            ('[COLOR red]Usuń Wszystko[/COLOR]',
             'RunPlugin(plugin://%s?mode=favoritesREM&ex_link=all)' % addon_id))
    if 'DOWNLOAD' in context:
        logger.debug(infoLabels)
        logger.debug('RunPlugin(plugin://{addon_id}?mode=download&ex_link={url}&title={title})'
                            .format(addon_id=addon_id,url=url, title=title))
        context_menu.append(('Download video',
                            'RunPlugin(plugin://{addon_id}?mode=download&ex_link={url}&title={title})'
                            .format(addon_id=addon_id,url=url, title=title)))
    if 'trailer' in infoLabels:
        context_menu.append(
            ('Zwiastun', 'XBMC.PlayMedia(%s)' % infoLabels.get('trailer')))
    return context_menu


def _user_folder_cda_(userF='K1'):
    user_folder = addon.getSetting(userF)
    if user_folder == 'true':
        user_folder_filtr = addon.getSetting(
            userF + '_filtr0')
        title = addon.getSetting(userF + '_title')
        if not title:
            title = user_folder_filtr.title()
        user_folder_filtr = cda.replace_chars(user_folder_filtr)
        user_folder_filtr = user_folder_filtr.lower()
        sel = addon.getSetting(userF + '_filtr1')
        dlugosci = ['all', 'krotkie', 'srednie', 'dlugie']
        dlugosc = dlugosci[int(sel)]
        sel = addon.getSetting(userF + '_filtr2')
        jakosci = ['all', '480p', '720p', '1080p']
        jakosc = jakosci[int(sel)]
        sel = addon.getSetting(userF + '_filtr3')
        sortowania = ['best', 'date', 'popular', 'rate', 'alf']
        sortowanie = sortowania[int(sel)]
        url = 'https://www.cda.pl/video/show/%s?duration=%s&section=vid&quality=%s&section=&s=%s&section=' % \
              (user_folder_filtr, dlugosc, jakosc, sortowanie)
        return {'url': url, 'title': '[COLOR lightblue]%s[/COLOR]' % title}
    return False
