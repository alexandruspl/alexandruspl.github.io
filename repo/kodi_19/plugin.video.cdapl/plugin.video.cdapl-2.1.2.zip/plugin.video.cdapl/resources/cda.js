//player_file = 'GH2Hb%60%60%5Db452%5DA%3D%5E%7E%3Auc%7Eg5y%3Ay05%267rwc4%3Cdhp%5E%60eabf%60e_ca%5E%3DB5hb3_b%60%603%606d5336ba67ae4c3226gc32_Q5'
//https://vwaw324.cda.pl/hUJhFMTStuMebydutiXF9g/1623718041/lqd93b0311b1e5dbbe32ef26c4baae84ba.mp4

M = function(a) {
    //String.fromCharCode(('Z' >= a ? 11 : 344) >= (c = a.charCodeAt(0) + 22) ? c : c - 11);
    a = a.replace('_XDDD', '');
    a = a.replace('_CDA', '');
    a = a.replace('_ADC', '');
    a = a.replace('_CXD', '');
    a = a.replace('_QWE', '');
    a = a.replace('_Q5', '');
    a = a.replace('_IKSDE', '');
    return ba(K(a))
};

ba = function(a) {
    return L(ca(K(a)))
};

K = function(a) {
    return a.replace(/[a-zA-Z]/g, function(a) {
        return String.fromCharCode(
            ('Z' >= a ? 90 : 122) >= (a = a.charCodeAt(0) + 13) ? a : a - 26)
    })
};

aa = function(a) {
    //String.fromCharCode(('Z' >= a ? 82 : 132) >= (c = a.charCodeAt(0) + 11) ? c : c - 55);
    return L(a)
};

ca = function(a) {
    return decodeURIComponent(a)
};

da = function(a) {
    a = a.replace('.cda.mp4', '');
    a = a.replace('.2cda.pl', '.cda.pl');
    a = a.replace('.3cda.pl', '.cda.pl');
    return -1 < a.indexOf('/upstream') ? (a = a.replace('/upstream', '.mp4/upstream'), 'https://' + a) : 'https://' + a + '.mp4'
};
L = function(a) {
    for (var b = [], e = 0; e < a.length; e++) {
        var f = a.charCodeAt(e);
        b[e] = 33 <= f && 126 >= f ? String.fromCharCode(33 + (f + 14) % 94) : String.fromCharCode(f)
    }
    return da(b.join(''))
};


N = function (a) {
    return !B(a, 'http') && !B(a, '.mp4') && !B(a, 'uggcf://')
};

//player_file && (N(player_file) && (player_file = M(player_file)), - 1 == player_file.indexOf('http') && (player_file = K(player_file)), - 1 == player_file.indexOf('.webm') && - 1 == player_file.indexOf('.mp4') && (player_file += '.mp4'), - 1 < player_file.indexOf('adc.mp4') && (player_file = player_file.replace('adc.mp4', '.mp4')));

