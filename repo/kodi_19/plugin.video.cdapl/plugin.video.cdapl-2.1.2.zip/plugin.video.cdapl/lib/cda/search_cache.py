# coding=utf-8
"""
Moduł zapisujący wyniki wyszukiwania na dysku
"""

import hashlib
import json
import os
import traceback
from time import time

import six
import xbmc
import xbmcvfs

from .. import logger

day_seconds = 24 * 3600
CACHE_DIR = xbmc.translatePath("special://temp/plugin.video.cdapl")


def _md5digest(string):
    string = six.ensure_binary(string)
    return hashlib.md5(string).hexdigest()


def load(ex_link, cache_days=1):
    """Ładuje wyniki z dysku"""
    try:
        cache_days = float(cache_days)
    except ValueError:
        cache_days = 0

    md5 = _md5digest(ex_link)
    data_path = os.path.join(CACHE_DIR, "%s.json" % md5)
    if xbmcvfs.exists(data_path):
        st = xbmcvfs.Stat(data_path)
        if time() - st.st_mtime() < cache_days * day_seconds and st.st_size() > 0:
            try:
                with open(data_path) as fp:
                    js = json.load(fp)
                    logger.log("LOAD_CACHED_SEARCH", logger.LOGDEBUG)
                    return js['items'], js['next_page']
            except Exception:
                logger.log('CDA_SEARCH_CACHE: %s' % traceback.format_exc(), logger.LOGWARNING)
    return [], False


def save(ex_link, items, next_page):
    """Zapis wyników wyszukiwania na dysku w postaci pliku json"""
    md5 = _md5digest(ex_link)
    data_path = os.path.join(CACHE_DIR, '%s.json' % md5)

    if not xbmcvfs.exists(CACHE_DIR):
        try:
            xbmcvfs.mkdir(CACHE_DIR)
        except Exception:
            logger.log('CDA_SEARCH_CACHE: %s' % traceback.format_exc(), logger.LOGWARNING)
            return

    try:
        with  open(data_path, 'w') as json_file:
            json.dump({'items': items, 'next_page': next_page}, json_file)
            logger.log("CACHE SEARCH: ex_link: %s, items:  %s" %
                       (ex_link, data_path))
    except Exception:
        logger.log('CDA_SEARCH_CACHE: %s' % traceback.format_exc(), logger.LOGWARNING)


def clean(cache_days, last_clean_time):
    try:
        cache_days = float(cache_days)
        last_clean_time = float(last_clean_time)
    except Exception:
        logger.log('CDA_SEARCH_CACHE: %s' % traceback.format_exc(), logger.LOGWARNING)
        return last_clean_time

    if last_clean_time + cache_days * day_seconds > time():
        return last_clean_time

    def delete_cached_files(days, dirname, fnames):
        mtime_diff = days * day_seconds

        curr_time = time()
        for fnm in fnames:
            if not fnm.endswith('.json'):
                continue
            fnm = os.path.join(dirname, fnm)
            st = os.stat(fnm)
            if abs(curr_time - st.st_mtime) > mtime_diff or st.st_size == 0:
                try:
                    os.unlink(fnm)
                except Exception as ex:
                    logger.log('CDA_SEARCH_CACHE: %s, %s' % (fnm, ex), logger.LOGWARNING)
                    logger.log('CDA_SEARCH_CACHE: %s' % traceback.format_exc(), logger.LOGWARNING)

    for top, _, fnames in os.walk(CACHE_DIR):
        delete_cached_files(cache_days, top, fnames)
    return time()
