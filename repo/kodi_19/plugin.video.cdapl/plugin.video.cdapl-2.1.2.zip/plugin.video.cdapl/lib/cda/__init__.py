# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 18:47:43 2016
"""
__all__ = ['search_cache', 'url_decrypt']

import json
import os
import re
import traceback
import codecs

import six
import xbmc
from six import unichr
from six.moves import html_entities as htmlentitydefs
from six.moves import http_cookiejar as cookielib
from six.moves import urllib_parse as urlparse
from six.moves import urllib_request as urllib2

if six.PY3:
    import xbmcvfs

    xbmc.translatePath = xbmcvfs.translatePath

from lib import packer, logger
from . import url_decrypt, dash

CDA_BASE_URL = 'https://www.cda.pl'
REQUEST_TIMEOUT = 10
COOKIE_PATH = os.path.join(xbmc.translatePath('special://temp/'), 'cookie_cda.tmp')
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0'

sort_methods = {'nowo dodane': 'new',
                'alfabetycznie': 'alpha',
                'najlepiej oceniane na Filmweb': 'best',
                'najczęściej oceniane na Filmweb': 'popular',
                'data premiery kinowej': 'release',
                'popularne w ciągu ostatnich 60 dni': 'views',
                'popularne w ciągu ostatnich 30 dni': 'views30'}

premium_quality_list = {'Wszystkie': '1,2,3',
                        'Wysoka jakość (720p, 1080p)': '1',
                        'Średnia jakość (480p)': '2',
                        'Niska jakość (360p)': '3'}

rot13 = codecs.getencoder('rot13')

def login(username, password, cookie_filename):
    login_data = {'username': username, 'password': password, 'submit_login': ''}
    url = 'https://www.cda.pl/login'
    ciacho = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(ciacho))
    urllib2.install_opener(opener)
    params = six.ensure_binary(urlparse.urlencode(login_data))
    status = False
    try:
        req = urllib2.Request(url, params)
        req.add_header('User-Agent', USER_AGENT)
        response = urllib2.urlopen(req, timeout=REQUEST_TIMEOUT)
        response_content = response.read()
        response.close()
        if username in response_content:
            ciacho.save(cookie_filename, ignore_discard=True)
            status = True
    except Exception:
        logger.warning(traceback.format_exc())
    return status


def get_UserFolder_obserwowani(url):
    content = _download(url)
    items = []
    folders = []
    match = re.compile(
        '@użytkownicy(.*?)<div class="panel-footer"></div>', re.DOTALL).findall(content)
    if match:
        data = re.compile(
            'data-user="(.*?)" href="(.*?)"(.*?)src="(.*?)"', re.DOTALL).findall(match[0])
        for l11l1llll11l1l_cda_ in data:
            folders.append({'path': l11l1llll11l1l_cda_[1] + '/folder-glowny', 'title': html_entity_decode(
                l11l1llll11l1l_cda_[0]), 'img': _add_https(l11l1llll11l1l_cda_[3])})
    return items, folders


def filter_items(ex_link, recursive=True, filtr_items={}):
    items = []
    folders = []
    items, folders, pagination = _generate_items(
        ex_link, recursive, items, folders)
    if recursive:
        pagination = (False, False)
    filtered_items = []
    if filtr_items:
        counter = 0
        key = list(filtr_items.keys())[0]
        value = six.ensure_str(filtr_items[key])
        for item in items:
            if value in item.get(key):
                counter += 1
                filtered_items.append(item)
        items = filtered_items
        logger.log('Filted %d items by [%s in %s]' % (counter, value, key))
    return items, folders, pagination


def replace_chars(input_str):
    trans_table = {'Ą': 'a', 'ą': 'a', 'Ę': 'e', 'ę': 'e',
                   'Ó': 'o', 'ó': 'o', 'Ć': 'c', 'ć': 'c',
                   'Ł': 'l', 'ł': 'l', 'Ń': 'n', 'ń': 'n',
                   'Ś': 's', 'ś': 's', 'Ź': 'z', 'ź': 'z',
                   'Ż': 'z', 'ż': 'z', ' ': '_'}

    trans_table = {ord(six.ensure_text(key)): six.ensure_text(val) for key, val in trans_table.items()}
    input_str = six.ensure_text(input_str).translate(trans_table)
    return six.ensure_str(input_str)


def get_items(url, is_premium=False, bcleantitle=1):
    logger.debug('GET ITEMS: '+str(url))
    url = replace_chars(url)
    content = _download(url)
    labels = re.compile(
        '<label(.*?)</label>', re.DOTALL).findall(content)
    next_link = re.compile(
        '<a class="sbmBigNext btn-my btn-large fiximg" href="(.*?)"').findall(content)
    items = []
    for label in labels:
        label = html_entity_decode(label)
        premium_purple = ''
        if 'premium' in label:
            if is_premium:
                premium_purple = '[COLOR purple](P)[/COLOR]'
            else:
                continue
        plot = re.compile('title="(.*)"').findall(label)
        label_href = re.compile('src="(.*)" ').findall(label)
        label_quality = re.compile(
            '<span class="hd-ico-elem hd-elem-pos">(.*?)</span>').findall(label)
        video_duration = re.compile(
            '<span class="timeElem">\\s*(.*?)\\s*</span>').findall(label)
        href_title = re.compile(
            '<a class=".*?link-title-visit.*?" href="(.*?/video/.*?)">(.*?)<').search(label)
        is_new = 'Nowość' if label.find(
            'Nowość') > 0 else ''
        year = ''
        if href_title:
            if href_title.lastindex == 2:
                href = href_title.group(1)
                url = href if href.startswith('http') else CDA_BASE_URL + href
                title = _decode_html_entities(href_title.group(2))
                video_duration = _get_duration(video_duration[0]) if video_duration else ''
                code = premium_purple
                code += label_quality[0] if label_quality else ''
                plot = _decode_html_entities(plot[0]) if plot else ''
                thumbnail_image = _add_https(label_href[0]) if label_href else ''
                if bcleantitle:
                    plot = '[B]%s[/B]\n%s' % (title, plot)
                    title, year, _ = _clean_title(title)
                items.append({'path': url, 'title': six.ensure_text(title), 'year': year,
                              'code': code, 'plot': six.ensure_text(plot), 'img': thumbnail_image,
                              'duration': video_duration, 'new': is_new, })

    if next_link:
        next_link = [p for p in next_link if '/video' in p]
        next_link = CDA_BASE_URL + next_link[-1] if next_link else False
    return items, next_link


def get_video_urls(url, tryIT=4):
    """
    returns         - url https://....-
    or list of [('720p', 'https://www.cda.pl/video/1946991f?wersja=720p'),...]
    """
    url = url.replace('/vfilm', '')
    if 'ebd.cda.pl' not in url:
        url = 'https://ebd.cda.pl/100x100/' + url.split('/')[-1]
    url_suffix = '|Cookie=PHPSESSID=1&Referer=http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf'
    content = _download(url)
    src = []
    if content == '':
        src.append(('Materiał został usunięty', ''))
        # return 'mp4', src

    dash_data = dash.get_data(content)
    if dash_data and isinstance(dash_data, dict) and 'stream_url' in dash_data.keys() and dash_data['stream_url']:
        return 'dash', dash_data

    video_niedostepne = content.find('To wideo jest niedostępne ')
    bad_browser = content.find('niedostępny na tej przeglądarce.')
    if video_niedostepne > 0:
        src.append(('To wideo jest niedostępne w Twoim kraju', ''))
    elif bad_browser > -1:
        src.append(('Niedostępny na tej przeglądarce.', ''))
    elif '?wersja' not in url:
        video_qualities = re.compile(
            '<a data-quality="(.*?)" (?P<H>.*?)>(?P<Q>.*?)</a>', re.DOTALL).findall(content)
        for quality in video_qualities:
            q_url = re.search('href="(.*?)"', quality[1])
            q_label = quality[2]
            if q_url:
                src.insert(0, (q_label, q_url.group(1)))
    if not src:
        src = _link_scan_cda(content)
        if src:
            src += url_suffix
        else:
            for _ in range(tryIT):
                content = _download(url)
                src = _link_scan_cda(content)
                if src:
                    src += url_suffix
                    break
    if not src:
        if content.find('Ten film jest dost'):
            src = [(
                'Ten film jest dostępny dla użytkowników premium. \
                Wtyczka może nie obsługiwać poprawnie zasobów premium',
                '')]
        else:
            src = [('Film niedostępny', '')]
    return 'mp4', src


#
# url = 'https://www.cda.pl/video/show/naznaczony_2010'
# url = 'https://www.cda.pl/video/show/naznaczony_2010?duration=krotkie&section=&quality=all&section=&s=best&section='
# url = 'https://www.cda.pl/info/film_pl_2016'

def grabInforFromLink(url):
    def correct_url(input_string):
        if input_string.startswith('//'):
            input_string = 'https' + input_string
        elif input_string.startswith('/'):
            input_string = 'https://www.cda.pl' + input_string
        elif not input_string.startswith('http'):
            input_string = ''
        return input_string

    out = {}
    if 'www.cda.pl/video/' not in url:
        return out
    content = _download(url)
    description = re.compile(
        '<meta property="og:description" content="(.*?)"', re.DOTALL).findall(content)
    title = re.compile(
        '<meta property="og:title" content="(.*?)"').findall(content)
    image = re.compile(
        '<meta property="og:image" content="(.*?)"').findall(content)
    user = re.compile(
        '<a class="link-primary" href="(.*?)" class="autor" title="">').findall(content)
    quality = re.compile('href=".+?wersja=(.+?)"').findall(content)
    duration = re.compile(
        '<meta itemprop=[\'"]duration[\'"] content=[\'"](.*?)[\'"]').findall(content)
    if title:
        title = _decode_html_entities(title[0])
        duration = ':'.join(re.compile('(\\d+)').findall(duration[0])) if duration else ''
        duration = _get_duration(duration) if duration else ''
        user = correct_url(user[0]) + '/folder-glowny' if user else ''
        code = quality[-1] if quality else ''
        description = _decode_html_entities(description[0]) if description else ''
        img_url = _add_https(image[0]) if image else ''

        out = {'path': url, 'title': six.ensure_text(title), 'code': code, 'plot':
            six.ensure_text(description), 'img': img_url, 'duration': duration,
               'user': six.ensure_text(user)}

    return out


def premium_film(url, params=''):
    if len(params) == 0:
        content = _download(url)
        out = _content_info(content)
        match = re.compile(
            'katalogLoadMore\\(page,"(.*?)","(.*?)",').findall(content)
        if match:
            params = '%d_%s_%s' % (2, match[0][0], match[0][1])
    else:
        params_list = params.split('_')
        params = str((int(params_list[0]), params_list[1], params_list[2], {}))
        json_req_data = '{"jsonrpc":"2.0","method":"katalogLoadMore","params":%s,"id":2}' % params
        content = _download(url.split(
            '?')[0] + '?d=2', data=json_req_data.replace("'", '"'), referer=True)
        json_data = json.loads(content).get('result') if content else {}
        if json_data.get('status') == 'continue':
            params = '%d_%s_%s' % (int(params_list[0]) + 1, params_list[1], params_list[2])
        else:
            params = ''
        out = _content_info(json_data.get('html', ''))
    return out, params


def load_json(json_url):
    content = None
    if os.path.exists(json_url):
        try:
            with open(json_url, 'r') as json_file:
                content = json_file.read()
        except IOError:
            pass
    if not content:
        return []
    return json.loads(html_entity_decode(content))


def folder_root(ex_link='', json_file='', path=''):
    """Generowanie folderu Root"""
    data = {'[COLOR white][B]Root[/B][/COLOR]': {'jsonfile': 'main.json', 'img': 'Media.png'}}
    if ex_link == '' or ex_link.startswith('/'):
        if json_file:
            data = load_json(json_file)
        if isinstance(data, dict):
            for key, val in data.items():
                if isinstance(val, dict):
                    try:
                        val.update({'jsonfile': os.path.join(path, 'json', val.get('jsonfile'))})
                    except Exception:
                        logger.log('CDA EXCEPT: %s, exception %s' % (key, traceback.format_exc()), logger.LOGERROR)
        return _load_json_data(data, ex_link)


def premium_videos():
    url = 'https://www.cda.pl/premium'
    content = _download(url)
    premium_list = re.compile('<li><a\\s+href="(https://www.cda.pl/premium/.*?)">(.*?)</a>.*?</li>', re.DOTALL).findall(
        content)
    out = []
    for video in premium_list:
        out.append({'title': _decode_html_entities(video[1]), 'path': video[0]})
    if out:
        out.insert(0, {'title': '[B]Wszystkie filmy[/B]', 'path': 'https://www.cda.pl/premium'})
    return out


def html_entity_decode(string):
    string = six.ensure_text(string)
    s = re.compile('&#?(\\w+?);').sub(_replace_entity, string)
    return six.ensure_str(s)


def _extract_video_link(content):
    src = ''
    http_link_start_pos = content.find('|||http')
    if http_link_start_pos > 0:
        http_link_end_pos = content.find('.split', http_link_start_pos)
        http_link_encoded = content[http_link_start_pos:http_link_end_pos]
        if http_link_encoded:
            http_link_encoded_before_player = http_link_encoded.split('player')[0]
            http_link_encoded_before_player = re.sub(
                '[|]+\\w{2,3}[|]+', '|', http_link_encoded_before_player, re.DOTALL)
            http_link_encoded_before_player = re.sub(
                '[|]+\\w{2,3}[|]+', '|', http_link_encoded_before_player, re.DOTALL)
            strings_to_replace = ['http', 'logo', 'width', 'height', 'true', 'static', 'false', 'video', 'player',
                                  'file', 'type', 'regions', 'none', 'czas', 'enabled', 'duration', 'controlbar',
                                  'match', 'bottom',
                                  'center', 'position', 'userAgent', 'navigator', 'config', 'html', 'html5',
                                  'provider', 'black',
                                  'horizontalAlign', 'canFireEventAPICalls', 'useV2APICalls', 'verticalAlign',
                                  'timeslidertooltipplugin',
                                  'overlays', 'backgroundColor', 'marginbottom', 'plugins', 'link', 'stretching',
                                  'uniform', 'static1',
                                  'setup', 'jwplayer', 'checkFlash', 'SmartTV', 'v001', 'creme', 'dock', 'autostart',
                                  'idlehide', 'modes',
                                  'flash', 'over', 'left', 'hide', 'player5', 'image', 'KLIKNIJ', 'companions',
                                  'restore', 'clickSign',
                                  'schedule', '_countdown_', 'countdown', 'region', 'else', 'controls', 'preload',
                                  'oryginalne', 'style',
                                  '620px', '387px', 'poster', 'zniknie', 'sekund', 'showAfterSeconds', 'images',
                                  'Reklama', 'skipAd',
                                  'levels', 'padding', 'opacity', 'debug', 'video3', 'close', 'smalltext', 'message',
                                  'class', 'align',
                                  'notice', 'media']
            for value in strings_to_replace:
                http_link_encoded_before_player = http_link_encoded_before_player.replace(
                    value, '')
            cleanup = http_link_encoded_before_player.replace('|', ' ').split()
            out = {'server': '', 'e': '', 'file': '', 'st': ''}
            if len(cleanup) == 4:
                for value in cleanup:
                    if value.isdigit():
                        out['e'] = value
                    elif re.match('[a-z]{2,}\\d{3}', value) and len(value) < 10:
                        out['server'] = value
                    elif len(value) == 22:
                        out['st'] = value
                    else:
                        out['file'] = value
                src = 'https://%s.cda.pl/%s.mp4?st=%s&e=%s' % (
                    out.get('server'), out.get('file'), out.get('st'), out.get('e'))
    return src


def _video_source(content):
    link = ''
    js_evals = re.compile(
        'eval(.*?)\\{\\}\\)\\)', re.DOTALL).findall(content)
    for js_eval in js_evals:
        js_eval = re.sub(' {2}', ' ', js_eval)
        js_eval = re.sub('\n', '', js_eval)
        try:
            unpacked_js = packer.unpack(
                js_eval)
        except:
            unpacked_js = ''
        if unpacked_js:
            unpacked_js = re.sub('\\\\', '', unpacked_js)
            file_link1 = re.compile(
                '[\'"]*file[\'"]*:\\s*[\'"](.+?)[\'"],', re.DOTALL).search(unpacked_js)
            file_link2 = re.compile(
                '[\'"]file[\'"][:\\s]*[\'"](.+?)[\'"]', re.DOTALL).search(unpacked_js)
            file_link_mp4 = re.search(
                '[\'"]file[\'"]:[\'"](.*?\\.mp4)[\'"]', unpacked_js)
            if file_link1:
                link = file_link1.group(1)
            elif file_link2:
                link = file_link2.group(1)
            elif file_link_mp4:
                link = file_link_mp4.group(1) + '.mp4'
            if link:
                break
    return link


def _link_scan_cda(content):
    """
        Scans for video link included encoded one
    """
    vid_link1 = re.compile(
        '[\'"]file[\'"][:\\s]*[\'"](.+?)[\'"]', re.DOTALL).search(content)
    res = re.search(r'player_data=(\\?["\'])(?P<player_data>.+?)\1', content, re.DOTALL)
    if res and res.lastgroup == 'player_data':
        player_data = res.group('player_data')
    else:
        player_data = ''

    logger.log('player_data: %s' % str(player_data))

    player_data = str(player_data) if player_data else ''
    player_data_noquot = player_data.replace('&quot;', '"')
    vid_link2 = re.compile('[\'"]*file[\'"]*:\\s*[\'"](.+?)[\'"],', re.DOTALL).search(player_data_noquot)
    if vid_link1:
        video_link = vid_link1.group(1)
    elif vid_link2:
        video_link = vid_link2.group(1)
    else:
        video_link = _video_source(content)
        if not video_link:
            video_link = _extract_video_link(content)

    if video_link and "http" not in video_link and ".mp4" not in video_link and "uggcf://" not in video_link:
        video_link = url_decrypt.decrypt(video_link)
    if video_link.startswith('uggc'):
        video_link, _ = rot13(video_link)
        logger.debug(video_link)
        video_link = video_link[:-7] + video_link[-4:]
    return video_link


def _add_https(url):
    return 'https:%s' % url if url.startswith('//') else url


def _generate_items(url, recursive=True, items=[], folders=[]):
    content = _download(url)
    data_file_ids_pos = [(a.start(), a.end())
                         for a in re.finditer('data-file_id="', content)]
    data_file_ids_pos.append((-1, -1))
    for i, _ in enumerate(data_file_ids_pos[:-1]):
        data_file_id_content = content[data_file_ids_pos[i][1]:data_file_ids_pos[i + 1][0]]
        match = re.compile(
            'class="link-title-visit" href="(.*?)">(.*?)</a>').findall(data_file_id_content)
        time_thumb_folds = re.compile(
            'class="time-thumb-fold">(.*?)</span>').findall(data_file_id_content)
        thumbnail_hd_ico = re.compile(
            'class="thumbnail-hd-ico">(.*?)</span>').findall(data_file_id_content)
        thumbnail_hd_ico = [
            a.replace('<span class="hd-ico-elem">', '') for a in thumbnail_hd_ico]
        thumbnails = re.compile(
            '<img[ \t\n]+class="thumb thumb-bg thumb-size"[ \t\n]+alt="(.*?)"[ \t\n]+src="(.*?)">', re.DOTALL).findall(
            data_file_id_content)
        if match:
            url = CDA_BASE_URL + match[0][0]
            title = _decode_html_entities(match[0][1])
            video_duration = _get_duration(time_thumb_folds[0]) if time_thumb_folds else ''
            code = thumbnail_hd_ico[0] if thumbnail_hd_ico else ''
            plot = _decode_html_entities(thumbnails[0][0]) if thumbnails else ''
            thumbnail_image = _add_https(thumbnails[0][1]) if thumbnails else ''

            items.append({'path': url, 'title': six.ensure_text(title), 'code': code, 'plot':
                six.ensure_text(plot), 'img': thumbnail_image, 'duration': video_duration})

    folder_area_hrefs = re.compile(
        'class="folder-area">[ \t\n]+<a[ \t\n]+href="(.*?)"', re.DOTALL).findall(content)
    name_folders = re.compile(
        '<span[ \t\n]+class="name-folder">(.*?)</span>', re.DOTALL).findall(content)
    if folder_area_hrefs:
        if len(name_folders) > len(folder_area_hrefs):
            name_folders = name_folders[1:]
        for i, val in enumerate(folder_area_hrefs):
            folders.append({'path': val, 'title': html_entity_decode(name_folders[i])})
    pagination_control_hrefs = re.compile(
        '<div class="paginationControl">[ \t\n]+<a class="btn btn-primary block" href="(.*?)"', re.DOTALL).findall(
        content)
    pagination_control_hrefs = pagination_control_hrefs[0] if pagination_control_hrefs else False
    previous_href = re.compile('<a href="(.*?)" class="previous">').findall(content)
    previous_href = previous_href[0] if previous_href else False
    pagination = (previous_href, pagination_control_hrefs)
    if recursive and pagination_control_hrefs:
        _generate_items(pagination_control_hrefs, recursive, items, folders)
    return items, folders, pagination


def _clean_title(title):
    pattern = re.compile('[\\[\\]{};/\\\\()]')
    year = ''
    label = ''
    etykiety = re.compile('lektor|pl|dubbing|napis[y]*', flags=re.I | re.X).findall(title.lower())
    if etykiety:
        label = ' [COLOR lightgreen] %s [/COLOR]' % ' '.join(
            etykiety)
    info_etykiety = ['lektor', 'dubbing', ' pl ',
                     'full', 'hd', '\\*', '720p', '1080p', '480p', '"']
    for info_tmp in info_etykiety:
        title = re.sub(info_tmp, '', title, flags=re.I | re.X)
    year_found = re.findall('\\d{4}', title)
    if year_found:
        year = year_found[-1]
        title = re.sub(year_found[-1], '', title)
    title = pattern.sub('', title).strip('-. .,')
    return title.strip(), year, label.strip()


def _download(url, data=None, cookies=None, referer=False):
    logger.log("download CDA: url %s" % url)
    if COOKIE_PATH and os.path.exists(COOKIE_PATH):
        cookie_jar_cda_ = cookielib.LWPCookieJar()
        cookie_jar_cda_.load(COOKIE_PATH)
        cookies = ';'.join(['%s=%s' % (c.name, c.value) for c in cookie_jar_cda_])
        opener = urllib2.build_opener(
            urllib2.HTTPCookieProcessor(cookie_jar_cda_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url, data)
    req.add_header('User-Agent', USER_AGENT)
    if referer:
        req.add_header('Referer', url)
        req.add_header('X-Requested-With', 'XMLHttpRequest')
        req.add_header('Content-Type', 'application/json')
    if cookies:
        req.add_header('Cookie', cookies)
    try:
        response = urllib2.urlopen(req, timeout=REQUEST_TIMEOUT)
        response_data_cda_ = response.read()
        response.close()
    except:
        response_data_cda_ = ''

    return six.ensure_str(response_data_cda_)


def _decode_html_entities(data):
    data = six.ensure_str(data)
    repl = {
        '&nbsp;': '', '&lt;br/&gt;': ' ', '&ndash;': '-', '&quot;': '"',
        '&amp;quot;': '"', '&oacute;': 'ó', '&Oacute;': 'Ó',
        '&amp;': '&', '\u0105': 'ą', '\u0104': 'Ą', '\u0107': 'ć', '\u0106': 'Ć',
        '\u0119': 'ę', '\u0118': 'Ę', '\u0142': 'ł', '\u0141': 'Ł',
        '\u0144': 'ń', '\u0143': 'Ń', '\u00f3': 'ó', '\u00d3': 'Ó', '\u015b': 'ś',
        '\u015a': 'Ś', '\u017a': 'ź', '\u0179': 'Ź', '\u017c': 'ż', '\u017b': 'Ż'
    }
    data = re.sub('&#\\d+;', '', data)
    data = re.sub('<br\\s*/>', '\n', data)
    for key, value in repl.items():
        data = data.replace(key, value)
    data = re.sub('&.+;', '', data)

    return data


def _replace_entity(m):
    string = m.group(1)
    if string.startswith('x'):
        return unichr(int(string[1:], 16))
    try:
        return unichr(int(string))
    except Exception:
        if string in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[string])
        else:
            return string


def _content_info(content):
    cover = [(a.start(), a.end()) for a in re.finditer(
        '<span class="cover-area">', content)]
    cover.append((-1, -1))
    out = []
    for i in range(len(cover[:-1])):
        item = content[cover[i][1]:cover[i + 1][0]]
        href = re.compile('<a href="(.*?)"').findall(item)
        title = re.compile('class="kino-title">(.*?)<').findall(item)
        cover_img = re.compile('src="(.*?)"').findall(item)
        quality = re.compile('"cloud-gray">(.*?p)<').findall(item)
        rating_str = re.compile(
            '<span class="marker">(.*?)<').findall(item)
        plot = re.compile(
            '<span class="description-cover-container">(.*?)<[/]*span', re.DOTALL).findall(item)
        if title and href:
            try:
                rating = float(
                    rating_str[0]) if rating_str else ''
            except:
                rating = ''
            out.append({
                'title': _decode_html_entities(title[0]),
                'path': CDA_BASE_URL + href[0] if not href[0].startswith('http') else href[0],
                'img': _add_https(cover_img[0]) if cover_img else '',
                'code': quality[-1] if quality else '',
                'rating': rating,
                'plot': _decode_html_entities(plot[0]) if plot else ''
            })
    return out


def _element_from_path(element, path=''):
    """
    Zwraca elementy listy element z indeksem w zmiennej "path" element['path']
    """
    if path:
        x = path.strip('/').split('/').pop()
        if x:
            element = element.get(six.ensure_text(x), element)
    return element


def _load_json_data(data, path):
    """obsługa ładowania ściągniętych plików json"""
    list_1 = []
    list_2 = []
    list_3 = _element_from_path(data, path)
    if isinstance(list_3, dict):
        for label, tmp in list_3.items():
            if isinstance(tmp, str) or six.PY2 and isinstance(tmp, six.text_type):
                list_1.append(
                    {'img': '', 'title': label, 'path': '', 'jsonfile': tmp})
            elif isinstance(tmp, dict) and 'jsonfile' in tmp:
                tmp['title'] = label
                tmp['path'] = ''
                list_1.append(tmp)
            else:
                label = six.ensure_str(label)
                list_1.append(
                    {'img': '', 'title': label, 'path': path + '/' + label, 'fanart': ''})
        if list_1:
            list_1 = sorted(list_1, key=lambda k: (
                k.get('idx', ''), k.get('title', '')))
    if isinstance(list_3, list):
        for tmp in list_3:
            if 'path' in tmp:
                list_2.append(tmp)
            elif 'folder' in tmp:
                filtr_items = tmp.get('flter_item', {})
                has_subfolders = tmp.get('subfoders', True)
                has_items = tmp.get('items', False)
                recursive = tmp.get('recursive', True)
                items, folders, _ = filter_items(
                    ex_link=tmp.get('folder', ''),
                    recursive=recursive,
                    filtr_items=filtr_items)
                if has_subfolders:
                    list_1.extend(folders)
                if has_items:
                    list_2.extend(items)
    return list_2, list_1


def _get_duration(input_str):
    return sum([a * b for a, b in zip([1, 60, 3600], map(int, input_str.split(':')[::-1]))])
