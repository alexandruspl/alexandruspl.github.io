# -*- coding: utf-8 -*-

from six.moves.urllib_parse import unquote

from .. import logger


def my_decrypt(a):
    # first replace very cringy joke, then apply decodeURIComponent
    a = unquote(a)
    logger.log('cda: %s' % str(a))
    if a.find('_') <= 0:
        return ''
    a = a[:a.rfind('_')]
    # store decrypted characters
    b = []
    for e in a:
        f = ord(e)
        b.append(chr(33 + (f + 14) % 94) if 33 <= f <= 126 else chr(f))
    # decrypted URL
    a = "".join(b)
    # more "obfuscation" to deal with
    a = a.replace(".cda.mp4", "")
    a = a.replace(".2cda.pl", ".cda.pl")
    a = a.replace(".3cda.pl", ".cda.pl")
    # return extracted file as URL to video file
    return "https://" + a + ".mp4"


decrypt = my_decrypt


# decrypt = M
# wszystko poniżej mieści się w my_decrypt xd, pół dnia stracone

# s = 'GH2Hb%60%60%5Db452%5DA%3D%5E%7E%3Auc%7Eg5y%3Ay05%267rwc4%3Cdhp%5E%60eabf%60e_ca%5E%3DB5hb3_b%60%603%606d5336ba67ae4c3226gc32_Q5'

def L(a):
    b = []
    for ch in a:
        f = ord(ch)
        b.append(chr(33 + (f + 14) % 94) if 33 <= f <= 126 else chr(f))
    return da(''.join(b))


def K(a):
    import codecs
    rot13 = codecs.getencoder('rot13')
    return rot13(a)[0]


def da(a):
    a = a.replace('.cda.mp4', '')
    a = a.replace('.2cda.pl', '.cda.pl')
    a = a.replace('.3cda.pl', '.cda.pl')
    return 'https://{}'.format(a.replace('/upstream', '.mp4/upstream')) if '/upstream' in a else 'https://' + a + '.mp4'


def ba(a):
    return aa(ca(K(a)))


def ca(a):
    return unquote(a)


def M(a):
    a = a.replace('_XDDD', '')
    a = a.replace('_CDA', '')
    a = a.replace('_ADC', '')
    a = a.replace('_CXD', '')
    a = a.replace('_QWE', '')
    a = a.replace('_Q5', '')
    a = a.replace('_IKSDE', '')
    return ba(K(a))


def aa(a):
    # String.fromCharCode(('Z' >= a ? 82 : 132) >= (c = a.charCodeAt(0) + 11) ? c : c - 55);
    return L(a)


'''
//javascript z player.js
s = 'GH2Hb%60%60%5Db452%5DA%3D%5E%7E%3Auc%7Eg5y%3Ay05%267rwc4%3Cdhp%5E%60eabf%60e_ca%5E%3DB5hb3_b%60%603%606d5336ba67ae4c3226gc32_Q5'
    //https://vwaw324.cda.pl/hUJhFMTStuMebydutiXF9g/1623718041/lqd93b0311b1e5dbbe32ef26c4baae84ba.mp4

M = function(a) {
    //String.fromCharCode(('Z' >= a ? 11 : 344) >= (c = a.charCodeAt(0) + 22) ? c : c - 11);
    a = a.replace('_XDDD', '');
    a = a.replace('_CDA', '');
    a = a.replace('_ADC', '');
    a = a.replace('_CXD', '');
    a = a.replace('_QWE', '');
    a = a.replace('_Q5', '');
    a = a.replace('_IKSDE', '');
    return ba(K(a))
};

ba = function(a) {
    return L(ca(K(a)))
};

K = function(a) {
    return a.replace(/[a-zA-Z]/g, function(a) {
        return String.fromCharCode(('Z' >= a ? 90 : 122) >= (a = a.charCodeAt(0) + 13) ? a : a - 26)
    })
};

aa = function(a) {
    //String.fromCharCode(('Z' >= a ? 82 : 132) >= (c = a.charCodeAt(0) + 11) ? c : c - 55);
    return L(a)
};

ca = function(a) {
    return decodeURIComponent(a)
};

da = function(a) {
    a = a.replace('.cda.mp4', '');
    a = a.replace('.2cda.pl', '.cda.pl');
    a = a.replace('.3cda.pl', '.cda.pl');
    return -1 < a.indexOf('/upstream') ? (a = a.replace('/upstream', '.mp4/upstream'), 'https://' + a) : 'https://' + a + '.mp4'
};
L = function(a) {
    for (var b = [], e = 0; e < a.length; e++) {
        var f = a.charCodeAt(e);
        b[e] = 33 <= f && 126 >= f ? String.fromCharCode(33 + (f + 14) % 94) : String.fromCharCode(f)
    }
    return da(b.join(''))
};
console.log(M(s))
'''
