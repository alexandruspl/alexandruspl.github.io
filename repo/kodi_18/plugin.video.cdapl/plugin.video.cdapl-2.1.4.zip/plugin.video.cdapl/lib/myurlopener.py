# -*- coding: utf-8 -*-

from six.moves.urllib_request import URLopener


class MyURLopener(URLopener):
    version = 'Mozilla 5.0'

def urlretrieve(url, save_to, progress_hook):
#   custom urlretrieve using URLopener
        opener = MyURLopener()
        opener.addheaders = [('Referer', 'http://static.cda.pl/flowplayer/flash/flowplayer.commercial-3.2.18.swf')]
        return opener.retrieve(url, save_to, progress_hook)