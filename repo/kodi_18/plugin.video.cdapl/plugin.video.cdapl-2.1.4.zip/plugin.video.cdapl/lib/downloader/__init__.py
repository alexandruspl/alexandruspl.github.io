# -*- coding: utf-8 -*-
import os
import socket
import traceback
import six
import xbmc
import xbmcaddon
from six.moves.urllib_error import HTTPError
from lib import logger
from lib.myurlopener import urlretrieve
from .ui import xbmc_ui as ui

if six.PY2:
    from xbmc import makeLegalFilename
else:
    from xbmcvfs import makeLegalFilename

STATE_DOWNLOADED = 1
STATE_WAITING = 0
STATE_ERR = 2

def get_download_dir():
    """
    Retrieve the download directory from user settings or prompt the user if not set.
    :return: The download directory path.
    """
    download_dir = xbmcaddon.Addon().getSetting('download_dir')
    if not download_dir:
        download_dir = ui.download_dialog()
    return download_dir

def filepath(download_dir, filename):
    """
    Generate a legal file path for the download.
    :param download_dir: Directory to save the file.
    :param filename: Name of the file.
    :return: The sanitized file path.
    """
    download_dir = six.ensure_binary(download_dir)
    filename = six.ensure_binary(filename)
    save_to = os.path.join(download_dir, filename)
    save_to = makeLegalFilename(save_to)
    return six.ensure_binary(save_to)

def resolve_file_conflict(save_to, filename):
    """
    Handle file conflicts by prompting the user for a new filename.
    :param save_to: The conflicting file path.
    :param filename: The original filename.
    :return: A resolved file path or None if the user cancels.
    """
    if os.path.exists(save_to):
        filename = ui.file_exists_dialog(filename)
        if not filename:
            return None
        save_to = filepath(os.path.dirname(save_to), filename)
    return save_to

def download(url, filename):
    """
    Download a file from a URL to the specified filename.
    :param url: The URL to download from.
    :param filename: The name of the file to save.
    :return: Tuple of URL and filename if successful, None otherwise.
    """
    filename = filename.replace('/', ' ').replace('\\', ' ')
    download_dir = get_download_dir()
    is_writable = False
    while not is_writable:
        if not download_dir:
            logger.warning("Download directory not selected.")
            return None

        save_to = filepath(download_dir, filename)
        save_to = resolve_file_conflict(save_to, filename)

        if not save_to:
            logger.info("Download canceled by the user.")
            return None

        # Test file writability without truncating
        if not os.access(download_dir, os.W_OK):
            logger.error("Directory not writable: %s " % (download_dir))
            ui.notification_dialog("Error", "Selected directory is not writable.")
            new_download_dir = ui.download_dialog()
            if not new_download_dir:  # Exit if user cancels
                logger.info("Download canceled due to unwritable directory.")
                return None
            
            download_dir = new_download_dir
            is_writable = False
        else:
            is_writable = True

    # Progress dialog
    progress = {'dialog': ui.progress_dialog_bg(), 'current': 0}
    progress['dialog'].create("Downloading", filename)

    def progress_hook(count, blocksize, filesize):
        """Update progress dialog."""
        if xbmc.Monitor().abortRequested():
            logger.info("Download aborted by user.")
            raise Exception('Download aborted')
        progress['current'] += blocksize
        progress['dialog'].update(min(100, int(progress['current'] * 100 / filesize)))

    try:
        # Set timeout locally for the download
        socket.setdefaulttimeout(60)
        urlretrieve(url, save_to, progress_hook)
        ui.notification_dialog("Download Complete", filename)
        return url, filename
    except HTTPError as e:
        logger.warning("HTTPError during download: %s " % e)
        ui.notification_dialog("Download Error", str(e))
    except IOError as e:
        logger.warning("IOError during download: %s" % e)
        ui.notification_dialog("Download Error", "An I/O error occurred.")
    except Exception as e:
        logger.error("Unexpected error: %s" % e)
        logger.warning(traceback.format_exc())
        ui.notification_dialog("Download Error", "Unexpected error occurred.")
    finally:
        progress['dialog'].close()

    return None