# -*- coding: utf-8 -*-

import os
import sys
import traceback

import xbmc
import xbmcaddon
from six.moves import urllib_parse as urlparse
from lib import logger

addon = xbmcaddon.Addon()
script_name = sys.argv[0]
if len(sys.argv) > 1:
    try:
        plugin_handle = int(sys.argv[1])
        args = urlparse.parse_qs(sys.argv[2][1:])
    except:
        plugin_handle = 0
        args = None
xbmc_profile_path = xbmc.translatePath(addon.getAddonInfo('profile'))

xbmc_favorites_path = os.path.join(
    xbmc_profile_path, 'favorites.json')


def gen_url(query):
    query = {key: value for key, value in query.items()}
    query_str = ''
    try:
        query_str = urlparse.urlencode(query)
    except UnicodeError:
        logger.warning(logger.log('GEN_URL: %s' % traceback.format_exc(), logger.LOGWARNING))
        logger.warning(query)
    return script_name + '?' + query_str


def get_media_path():
    return addon.getAddonInfo('path') + '/resources/media/'
