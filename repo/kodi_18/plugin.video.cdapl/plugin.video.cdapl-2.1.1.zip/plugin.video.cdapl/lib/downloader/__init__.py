# -*- coding: utf-8 -*-
import six
from six.moves.urllib_request import urlretrieve
from six.moves.urllib_error import HTTPError

import traceback

from lib.common import addon
import os
from lib import logger
from .ui import xbmc_ui as ui

if six.PY2:
    from xbmc import makeLegalFilename
else:
    from xbmcvfs import makeLegalFilename


STATE_DOWNLOADED = 1
STATE_WAITING = 0
STATE_ERR = 2


def get_download_dir():
    download_dir = addon.getSetting('download_dir')
    if not download_dir:
        download_dir = ui.download_dialog()
    return download_dir


def download(url, filename):
    filename = filename.replace('/', ' ').replace('\\', ' ')
    is_writable = False
    download_dir = get_download_dir()
    while not is_writable:
        if not download_dir:
            return

        save_to = filepath(download_dir, filename)
        if os.path.exists(save_to):
            filename = ui.file_exists_dialog(filename)
            if filename:
                save_to = filepath(download_dir, filename)
            else:
                return

        try:
            with open(save_to, 'w') as f:
                f.truncate()
                is_writable = True
        except (FileNotFoundError, PermissionError):
            is_writable = False
            download_dir = ui.download_dialog()

    logger.debug((url, save_to))

    progress = {'dialog': ui.progress_dialog_bg(), 'current': 0}
    progress['dialog'].create("Pobieranie", filename)

    def progress_hook(a, b, c):
        progress['current'] = progress['current'] + b
        progress['dialog'].update(int(progress['current'] * 100 / c))

    try:
        result = urlretrieve(url, save_to, progress_hook)
    except HTTPError as e:
        logger.warning("DOWNLOADER: {}".format(traceback.format_exc()))
        ui.notification_dialog("Błąd pobierania", e.msg)
    finally:
        progress['dialog'].close()
    return url, filename


def filepath(download_dir, filename):
    save_to = os.path.join(download_dir, filename)
    save_to = makeLegalFilename(save_to)
    save_to = six.ensure_text(save_to)
    return save_to


