import sqlite3
import traceback
import six
from lib import logger


class URLDb:
    def __init__(self, sqlite_connection, table_name='download'):
        """
        Initialize the database handler.
        :param sqlite_connection: SQLite connection object.
        :param table_name: Name of the table to manage.
        """
        self._sqlite_connection = sqlite_connection
        self._table = table_name
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute(f'''
                    CREATE TABLE IF NOT EXISTS {self._table} (
                        url TEXT PRIMARY KEY,
                        filename TEXT,
                        state INTEGER
                    )
                ''')
        except sqlite3.Error as e:
            logger.warning("Error creating table '%s': %s" % (self._table, e))
            logger.warning(traceback.format_exc())

    def _log_error(self, context):
        """Log database errors with context."""
        logger.warning("Database error during %s" % context)
        logger.warning(traceback.format_exc())

    def add(self, url, filename, state=0):
        """
        Add a new record to the database or ignore if it exists.
        :param url: The URL of the download.
        :param filename: The associated filename.
        :param state: The initial state of the download.
        :return: True if the operation succeeded, False otherwise.
        """
        try:
            filename = six.ensure_text(filename)
            with self._sqlite_connection:
                self._sqlite_connection.execute(f'''
                    INSERT OR IGNORE INTO {self._table} (url, filename, state) 
                    VALUES (:url, :filename, :state)
                ''', {'url': url, 'filename': filename, 'state': state})
            return True
        except sqlite3.Error:
            self._log_error("add")
            return False

    def next(self):
        """
        Get the next download with state=0.
        :return: The next record as a tuple or None if no records exist.
        """
        try:
            rs = self._sqlite_connection.execute(f'''
                SELECT * FROM {self._table} WHERE state=0 LIMIT 1
            ''')
            return rs.fetchone()
        except sqlite3.Error:
            self._log_error("next")
            return None

    def set_state(self, url, download_state):
        """
        Update the state of a download.
        :param url: The URL of the download.
        :param download_state: The new state to set.
        :return: True if the operation succeeded, False otherwise.
        """
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute(f'''
                    UPDATE {self._table} 
                    SET state = :state 
                    WHERE url = :url
                ''', {'state': download_state, 'url': url})
            return True
        except sqlite3.Error:
            self._log_error("set_state")
            return False

    def set_filename(self, url, filename):
        """
        Update the filename of a download.
        :param url: The URL of the download.
        :param filename: The new filename to set.
        :return: True if the operation succeeded, False otherwise.
        """
        try:
            filename = six.ensure_text(filename)
            with self._sqlite_connection:
                self._sqlite_connection.execute(f'''
                    UPDATE {self._table} 
                    SET filename = :filename 
                    WHERE url = :url
                ''', {'filename': filename, 'url': url})
            return True
        except sqlite3.Error:
            self._log_error("set_filename")
            return False

    def delete(self, url):
        """
        Delete a download by its URL.
        :param url: The URL of the download to delete.
        :return: True if the operation succeeded, False otherwise.
        """
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute(f'''
                    DELETE FROM {self._table} 
                    WHERE url = :url
                ''', {'url': url})
            return True
        except sqlite3.Error:
            self._log_error("delete")
            return False