# -*- coding: utf-8 -*-

import xbmcgui
from abc import abstractmethod, ABCMeta

class ui(ABCMeta):
    @staticmethod
    @abstractmethod
    def download_dialog():
        pass

    @staticmethod
    @abstractmethod
    def file_exists_dialog(filename):
        pass

    @staticmethod
    @abstractmethod
    def progress_dialog_bg():
        pass

    @staticmethod
    @abstractmethod
    def notification_dialog(heading, msg):
        pass

class xbmc_ui(ui):
    @staticmethod
    def download_dialog():
        return xbmcgui.Dialog().browseSingle(3, "Katalog pobierania", 'files')

    @staticmethod
    def file_exists_dialog(filename):
        return xbmcgui.Dialog().input('Plik już istnieje', filename)

    @staticmethod
    def progress_dialog_bg():
        return xbmcgui.DialogProgressBG()

    @staticmethod
    def notification_dialog(heading, msg):
        xbmcgui.Dialog().notification(heading, msg)
