# -*- coding: utf-8 -*-

import sys
import traceback

import xbmcaddon
from six.moves import urllib_parse as urlparse

from lib import logger

if len(sys.argv) > 1:
    try:
        plugin_handle = int(sys.argv[1])

    except:
        plugin_handle = 0



def gen_url(query):
    query = {key: value for key, value in query.items()}
    query_str = ''
    try:
        query_str = urlparse.urlencode(query)
    except UnicodeError:
        logger.warning('GEN_URL: %s' % traceback.format_exc())
        logger.warning(query)
    return sys.argv[0] + '?' + query_str


def get_media_path():
    return xbmcaddon.Addon().getAddonInfo('path') + '/resources/media/'
