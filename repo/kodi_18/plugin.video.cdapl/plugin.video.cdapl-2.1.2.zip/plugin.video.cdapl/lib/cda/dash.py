# -*- coding: utf-8 -*-
import json
import re
import sys
import traceback
import six

import xbmcgui
import xbmcplugin
from six.moves import urllib_parse as parse
from .. import logger


PROTOCOL='mpd'
DRM='com.widevine.alpha'
HEADERS = {'x-dt-custom-data' : 'eyJ1c2VySWQiOiJhbm9uaW0iLCJzZXNzaW9uSWQiOiJ1YU1DWEtNeUM4T2o4WkhRSDd4eWZKb0M4ajkiLCJtZXJjaGFudCI6ImNkYSJ9',
        # 'Referer' : 'https://www.cda.pl/video/7731994b9/vfilm',
        'Origin' : 'https://www.cda.pl/',
        'User-Agent' : 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0',
        'Accept-Encoding' : 'gzip deflate br',
        'content-type' : ''
        }


def play(stream_url, key):
    HEADERS.update({'x-dt-custom-data':key})
    headers=parse.urlencode(HEADERS)
    license_url='https://lic.drmtoday.com/license-proxy-widevine/cenc/?specConform=true|%s|R{SSM}|' % headers # [license-server url]|[Header]|[Post-Data]|[Response] 
    try:
        import inputstreamhelper
    except ImportError:
        logger.warning(traceback.format_exc())
        xbmcgui.Dialog().notification("Inputstreamhelper not available", "DASH video reguires inpustreamhelper")
        return

    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setContentLookup(False)
        play_item.setMimeType('application/dash+xml')

        if six.PY3:
            play_item.setProperty(
                'inputstream', is_helper.inputstream_addon)
        else:
            play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)
        play_item.setProperty('inputstream.adaptive.stream_headers', headers)
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.license_type', DRM)
        play_item.setProperty('inputstream.adaptive.license_key', license_url )
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)


def get_data(content):
    player_data = re.compile("<div.*?player_data='(.*?)'.*?</div>", re.DOTALL).search(content)
    if player_data and player_data.lastindex:
        try:
            player_json = json.loads(player_data.group(player_data.lastindex))
        except json.decoder.JSONDecodeError:
            logger.warning(traceback.format_exc())
        else:
            return {'stream_url':player_json['video']['manifest'], 'key':player_json['video']['manifest_drm_header']}
