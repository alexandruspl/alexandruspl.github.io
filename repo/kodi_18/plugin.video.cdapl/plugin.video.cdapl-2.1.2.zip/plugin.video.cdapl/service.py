# -*- coding: utf-8 -*-
import os
import sqlite3

import six
import xbmc
import xbmcaddon

from lib import downloader, logger
from lib.downloader.db import URLDb

if six.PY2:
    from xbmc import translatePath
else:
    from xbmcvfs import translatePath



def main():
    DB_PATH = translatePath('special://temp/plugin.video.cdapl/cda.db')
    if xbmcaddon.Addon().getSetting('db_path') != DB_PATH:
        xbmcaddon.Addon().setSetting('db_path', DB_PATH)
    if not os.path.exists(os.path.dirname(DB_PATH)):
        try:
            os.makedirs(os.path.dirname(DB_PATH))
        except OSError:
            logger.warning('CDA SERVICE: Can\'t create database directory')
            return
    cn = sqlite3.connect(DB_PATH)
    url_db = URLDb(cn)
    while not xbmc.Monitor().abortRequested():
        url_data = url_db.next()
        if url_data:
            result = downloader.download(url_data[0], url_data[1])
            if result:
                url_db.set_state(url_data[0], downloader.STATE_DOWNLOADED)
                url_db.set_filename(url_data[0], result[1])
            else:
                url_db.set_state(url_data[0], downloader.STATE_ERR)

        xbmc.Monitor().waitForAbort(0.1)

if __name__ == '__main__':
    main()