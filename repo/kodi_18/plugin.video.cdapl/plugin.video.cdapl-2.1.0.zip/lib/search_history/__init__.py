# -*- coding: utf-8 -*-
from __future__ import with_statement, print_function
import xbmc

from .storage import JsonStorage

cache = JsonStorage(xbmc.translatePath("special://temp/plugin.video.cdapl/"))


def get():
    """Zwraca listę z historią wyszukiwania"""
    return cache.get()


def add(input_string):
    """Dodaje element do historii wyszukiwania"""
    search_history_cda_ = get()
    if search_history_cda_ == [''] or not search_history_cda_:
        search_history_cda_ = []

    search_history_cda_.insert(0, input_string)
    cache.set(search_history_cda_)


def remove(input_string):
    """Usuwa element z listy wyszukiwania"""
    search_history_cda_ = get()
    search_history_cda_.remove(input_string)
    if search_history_cda_:
        cache.set(search_history_cda_)
    else:
        clear()


def clear():
    """Usuwa całą historię wyszukiwania"""
    cache.set([])
