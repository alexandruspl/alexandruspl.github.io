# -*- coding: utf-8 -*-

import xbmcgui
from abc import abstractmethod, ABCMeta

class ui(ABCMeta):
    @staticmethod
    @abstractmethod
    def download_dialog(self):
        pass

    @staticmethod
    @abstractmethod
    def file_exists_dialog(self, filename):
        pass

    @staticmethod
    @abstractmethod
    def progress_dialog_bg(self):
        pass

    @staticmethod
    @abstractmethod
    def notification_dialog(self, heading, msg):
        pass

class xbmc_ui(ui):
    @staticmethod
    def download_dialog():
        return xbmcgui.Dialog().browseSingle(3, "Katalog pobierania", 'files')

    @staticmethod
    def file_exists_dialog( filename, xdd=False):
        return xbmcgui.Dialog().input('Plik już istnieje', filename)

    @staticmethod
    def progress_dialog_bg():
        return xbmcgui.DialogProgressBG()

    @staticmethod
    def notification_dialog(heading, msg):
        xbmcgui.Dialog().notification(heading, msg)