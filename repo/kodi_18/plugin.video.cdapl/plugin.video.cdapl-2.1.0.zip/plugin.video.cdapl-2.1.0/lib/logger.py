# -*- coding: utf-8 -*-
"""
Logging module
"""
from __future__ import print_function

import six

try:
    from xbmc import log, LOGDEBUG, LOGINFO, LOGWARNING, LOGERROR

    LOGNOTICE = LOGINFO
except ImportError as e:
    LOGDEBUG = 0
    LOGINFO = 1
    LOGNOTICE = LOGINFO
    LOGWARNING = 3
    LOGERROR = 4


    def log(msg, level=LOGDEBUG):
        print(msg, level)

_log = log


def log(msg, level=LOGDEBUG):
    if not isinstance(msg, (six.text_type, six.binary_type)):
        msg = str(msg)
    msg = six.ensure_str(msg)
    _log(msg, level)


def warning(msg):
    log(msg, LOGWARNING)


def error(msg):
    log(msg, LOGERROR)


def info(msg):
    log(msg, LOGINFO)


def debug(msg):
    log(msg, LOGDEBUG)
