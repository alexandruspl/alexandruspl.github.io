import sqlite3
import traceback
import six
from lib import logger

class URLDb:
    _sqlite_connection = None
    _table = 'download'

    def __init__(self, sqlite_connection):
        self._sqlite_connection = sqlite_connection
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute(
                    'create table if not exists download (url text primary key, filename text, state integer)')
        except sqlite3.Error:
            logger.warning(traceback.format_exc())

    def add(self, url, filename, state=0):
        try:
            filename=six.ensure_text(filename)
            with self._sqlite_connection:
                self._sqlite_connection.execute('insert or ignore into download values (:url, :filename, :state)',
                                                {'url': url, 'filename': filename, 'state': state})
        except sqlite3.Error:
            logger.warning(traceback.format_exc())

    def next(self):
        try:
            rs = self._sqlite_connection.execute("select * from download where state=0 limit 1")
            return rs.fetchone()
        except sqlite3.Error:
            logger.warning(traceback.format_exc())

    def set_state(self, url, download_state):
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute("update download set state=? where url=?", (download_state, url))
        except sqlite3.Error:
            logger.warning(traceback.format_exc())

    def set_filename(self, url, filename):
        try:
            filename=six.ensure_text(filename)
            with self._sqlite_connection:
                self._sqlite_connection.execute("update download set filename=? where url=?", (filename, url))
        except sqlite3.Error:
            logger.warning(traceback.format_exc())

    def delete(self, url):
        try:
            with self._sqlite_connection:
                self._sqlite_connection.execute('delete from download where url=?', (url,))
        except sqlite3.Error:
            logger.warning(traceback.format_exc())
