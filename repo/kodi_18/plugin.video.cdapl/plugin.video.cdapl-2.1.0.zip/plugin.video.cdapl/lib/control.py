# -*- coding: utf-8 -*-
# l11ll1ll11l11l1l_cda_.py
"""
    Covenant Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
# http://kodi.discavehb.com/repo/script.module.covenant/lib/resources/lib/modules/control.py

import os
import sys
import urllib

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from xbmcaddon import Addon

setSetting = Addon().setSetting
jsonrpc = xbmc.executeJSONRPC
xbmcgui_window_10000 = xbmcgui.Window(10000)
xbmcgui_dialog_cda_ = xbmcgui.Dialog()
xbmcgui_dialog_progress = xbmcgui.DialogProgress()
xbmcgui_ControlButton = xbmcgui.ControlButton
xbmcgui_ControlImage = xbmcgui.ControlImage
xbmc_Keyboard = xbmc.Keyboard
xbmc_execute_builtin = xbmc.executebuiltin
xbmc_skin_dir = xbmc.getSkinDir()
xbmc_player = xbmc.Player()
xbmc_playlist_video = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
xbmcplugin_setResolvedUrl = xbmcplugin.setResolvedUrl
xbmc_vfs_file_cda_ = xbmcvfs.File
xbmcvfs_mkdir = xbmcvfs.mkdir
xbmcvfs_delete = xbmcvfs.delete
xbmcvfs_rmdir = xbmcvfs.rmdir
addon_profile_path_cda_ = xbmc.translatePath(
    Addon().getAddonInfo('profile'))
settings_path_cda_ = os.path.join(addon_profile_path_cda_, 'settings.xml')
views_db_path_cda_ = os.path.join(addon_profile_path_cda_, 'views.db')
bookmarks_path = os.path.join(addon_profile_path_cda_, 'bookmarks.db')
providers13_path = os.path.join(addon_profile_path_cda_, 'providers.13.db')
meta5_path = os.path.join(addon_profile_path_cda_, 'meta.5.db')
library_path = os.path.join(addon_profile_path_cda_, 'library.db')
cache_path = os.path.join(addon_profile_path_cda_, 'cache.db')
key = 'RgUkXp2s5v8x/A?D(G+KbPeShVmYq3t6'
iv = 'p2s5v8y/B?E(H+Mb'


def addonIcon():
    l1l1111111l11l1l_cda_ = appearance()
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'icon.png')
    return Addon().getAddonInfo('icon')


def addonThumb():
    l1l1111111l11l1l_cda_ = appearance(
    )
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'poster.png')
    elif l1l1111111l11l1l_cda_ == '-':
        return 'DefaultFolder.png'
    return Addon().getAddonInfo('icon')


def addonPoster():
    l1l1111111l11l1l_cda_ = appearance(
    )
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'poster.png')
    return 'DefaultVideo.png'


def addonBanner():
    l1l1111111l11l1l_cda_ = appearance(
    )
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'banner.png')
    return 'DefaultVideo.png'


def addonFanart():
    l1l1111111l11l1l_cda_ = appearance(
    )
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'fanart.jpg')
    return Addon().getAddonInfo('fanart')


def addonNext():
    l1l1111111l11l1l_cda_ = appearance(
    )
    l1lll1l1l11l1l_cda_ = artPath()
    if not (l1lll1l1l11l1l_cda_ is None and l1l1111111l11l1l_cda_ in ['-', '']):
        return os.path.join(l1lll1l1l11l1l_cda_, 'next.png')
    return 'DefaultVideo.png'


def addonId():
    return Addon().getAddonInfo('id')


def addonName():
    return Addon().getAddonInfo('name')


def get_plugin_url(plugin_url):
    query = urllib.urlencode(plugin_url)

    l1l111l1lll11l1l_cda_ = sys.argv[0]
    if not l1l111l1lll11l1l_cda_:
        l1l111l1lll11l1l_cda_ = addonId()
    return l1l111l1lll11l1l_cda_ + '?' + query


def artPath():
    l1l1111111l11l1l_cda_ = appearance()
    if l1l1111111l11l1l_cda_ in ['-', '']:
        return
    elif xbmc.getCondVisibility('System.HasAddon(script.covenant.artwork)'):
        return os.path.join(Addon('script.covenant.artwork').getAddonInfo('path'), 'resources', 'media',
                            l1l1111111l11l1l_cda_)


def appearance():
    l11l1lll11l11l1l_cda_ = Addon().getSetting('appearance.1').lower() if xbmc.getCondVisibility(
        'System.HasAddon(script.covenant.artwork)') else Addon().getSetting('appearance.alt').lower()
    return l11l1lll11l11l1l_cda_


def artwork():
    xbmc_execute_builtin('RunPlugin(plugin://script.covenant.artwork)')


def infoDialog(message, heading=Addon().getAddonInfo('name'), icon='', time=3000, sound=False):
    if icon == '':
        icon = addonIcon()
    elif icon == 'INFO':
        icon = xbmcgui.NOTIFICATION_INFO
    elif icon == 'WARNING':
        icon = xbmcgui.NOTIFICATION_WARNING
    elif icon == 'ERROR':
        icon = xbmcgui.NOTIFICATION_ERROR
    xbmcgui_dialog_cda_.notification(heading, message, icon, time, sound=sound)


def yesnoDialog(l1l11111l1l11l1l_cda_, l1l111lllll11l1l_cda_, l1l1111l11l11l1l_cda_,
                l11l1ll11ll11l1l_cda_=Addon().getAddonInfo('name'), l11l1l1111l11l1l_cda_='', l11lll1ll1l11l1l_cda_=''):
    return xbmcgui_dialog_cda_.yesno(l11l1ll11ll11l1l_cda_, l1l11111l1l11l1l_cda_, l1l111lllll11l1l_cda_,
                                     l1l1111l11l11l1l_cda_, l11l1l1111l11l1l_cda_, l11lll1ll1l11l1l_cda_)


def selectDialog(list, l11l1ll11ll11l1l_cda_=Addon().getAddonInfo('name')):
    return xbmcgui_dialog_cda_.select(l11l1ll11ll11l1l_cda_, list)


def metaFile():
    if xbmc.getCondVisibility('System.HasAddon(script.covenant.metadata)'):
        return os.path.join(Addon('script.covenant.metadata').getAddonInfo('path'), 'resources', 'data', 'meta.db')


def apiLanguage(input=None):
    country_codes = {
        'Bulgarian': 'bg', 'Chinese': 'zh', 'Croatian': 'hr', 'Czech': 'cs', 'Danish': 'da', 'Dutch': 'nl',
        'English': 'en', 'Finnish': 'fi', 'French': 'fr', 'German': 'de', 'Greek': 'el', 'Hebrew': 'he',
        'Hungarian': 'hu', 'Italian': 'it',
        'Japanese': 'ja', 'Korean': 'ko', 'Norwegian': 'no', 'Polish': 'pl', 'Portuguese': 'pt', 'Romanian': 'ro',
        'Russian': 'ru', 'Serbian': 'sr', 'Slovak': 'sk', 'Slovenian': 'sl', 'Spanish': 'es', 'Swedish': 'sv',
        'Thai': 'th', 'Turkish': 'tr', 'Ukrainian': 'uk'}
    trakt_country_codes = [
        'bg', 'cs', 'da', 'de', 'el', 'en', 'es', 'fi', 'fr', 'he', 'hr', 'hu',
        'it', 'ja', 'ko', 'nl', 'no', 'pl', 'pt', 'ro', 'ru', 'sk', 'sl', 'sr', 'sv', 'th', 'tr', 'uk', 'zh']
    tvdb_country_codes = [
        'en', 'sv', 'no', 'da', 'fi', 'nl', 'de', 'it', 'es',
        'fr', 'pl', 'hu', 'el', 'tr', 'ru', 'he', 'ja', 'pt', 'zh', 'cs', 'sl', 'hr', 'ko']
    youtube_country_codes = [
        'gv', 'gu', 'gd', 'ga', 'gn', 'gl', 'ty', 'tw', 'tt', 'tr', 'ts', 'tn', 'to', 'tl', 'tk', 'th', 'ti', 'tg',
        'te', 'ta', 'de', 'da', 'dz', 'dv', 'qu', 'zh', 'za', 'zu', 'wa', 'wo', 'jv', 'ja', 'ch', 'co', 'ca', 'ce',
        'cy', 'cs', 'cr', 'cv', 'cu', 'ps', 'pt', 'pa', 'pi', 'pl', 'mg', 'ml', 'mn', 'mi', 'mh', 'mk', 'mt', 'ms',
        'mr', 'my', 've', 'vi', 'is', 'iu', 'it', 'vo', 'ii', 'ik', 'io', 'ia', 'ie', 'id', 'ig', 'fr', 'fy', 'fa',
        'ff', 'fi', 'fj', 'fo', 'ss', 'sr', 'sq', 'sw', 'sv', 'su', 'st', 'sk', 'si', 'so', 'sn', 'sm', 'sl', 'sc',
        'sa', 'sg', 'se', 'sd', 'lg', 'lb', 'la', 'ln', 'lo', 'li', 'lv', 'lt', 'lu', 'yi', 'yo', 'el', 'eo', 'en',
        'ee', 'eu', 'et', 'es', 'ru', 'rw', 'rm', 'rn', 'ro', 'be', 'bg', 'ba', 'bm', 'bn', 'bo', 'bh', 'bi', 'br',
        'bs', 'om', 'oj', 'oc', 'os', 'or', 'xh', 'hz', 'hy', 'hr', 'ht', 'hu', 'hi', 'ho', 'ha', 'he', 'uz', 'ur',
        'uk', 'ug', 'aa', 'ab', 'ae', 'af', 'ak', 'am', 'an', 'as', 'ar', 'av', 'ay', 'az', 'nl', 'nn', 'no', 'na',
        'nb', 'nd', 'ne', 'ng', 'ny', 'nr', 'nv', 'ka', 'kg', 'kk', 'kj', 'ki', 'ko', 'kn', 'km', 'kl', 'ks', 'kr',
        'kw', 'kv', 'ku', 'ky']
    name = None
    name = Addon().getSetting('api.language')
    if not name:
        name = 'AUTO'

    try:
        name = country_codes[name]
    except:
        name = 'en'
    tmp = {
        'trakt': name} if name in trakt_country_codes else {'trakt': 'en'}
    tmp[
        'tvdb'] = name if name in tvdb_country_codes else 'en'
    tmp[
        'youtube'] = name if name in youtube_country_codes else 'en'
    if input:
        tmp['trakt'] = [i[0]
                        for i in country_codes.iteritems() if i[1] == tmp['trakt']][0]
        tmp['tvdb'] = [i[0]
                       for i in country_codes.iteritems() if i[1] == tmp['tvdb']][0]
        tmp['youtube'] = [i[0]
                          for i in country_codes.iteritems() if i[1] == tmp['youtube']][0]
    return tmp


def version():
    version_string = ''
    try:
        version = Addon('xbmc.addon').getAddonInfo('version')
    except:
        version = '999'
    for i in version:
        if i.isdigit():
            version_string += i
        else:
            break
    return int(version_string)


def openSettings(query=None, id=Addon().getAddonInfo('id')):
    try:
        idle()
        xbmc_execute_builtin('Addon.OpenSettings(%s)' % id)
        if query is None:
            raise Exception()
        c, f = query.split('.')
        xbmc_execute_builtin('SetFocus(%i)' % (int(c) + 100))
        xbmc_execute_builtin('SetFocus(%i)' % (int(f) + 200))
    except:
        return


def refresh():
    return xbmc_execute_builtin('Container.Refresh')


def busy():
    return xbmc_execute_builtin('ActivateWindow(busydialog)')


def idle():
    return xbmc_execute_builtin('Dialog.Close(busydialog)')


def queueItem():
    return xbmc_execute_builtin('Action(Queue)')
